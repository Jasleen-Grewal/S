package com.example.n01204206.milestone;

public class DataStructure {

    private String temperature;
    private String humidity;
    private String moisture;


    public DataStructure(){

    }
    public DataStructure( String temperature, String humidity, String moisture) {

        this.temperature = temperature;
        this.humidity = humidity;
        this.moisture = moisture;

    }


    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getMoisture() {
        return moisture;
    }

    public void setMoisture(String moisture) {
        this.moisture = moisture;
    }

}
